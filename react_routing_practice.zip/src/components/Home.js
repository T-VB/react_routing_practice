import React from "react";

const Home = () => {
  return <div>Welcome!</div>;
};

export default Home;
