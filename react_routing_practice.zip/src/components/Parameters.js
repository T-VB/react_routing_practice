import React from "react";
import { useParams } from "react-router-dom";

const Parameters = (props) => {
  // ^^^Destructure from useParams hook from import
  const { word, color, bgColor } = useParams();

  //***is this input Not a Number?
  //.. then render this color and bgColor that was inputted
  //..otherwise, print the number that user inputted
  return (
    <div>
      {isNaN(word) ? (
        <p style={color ? { color: color, backgroundColor: bgColor } : null}>
          This is a word: {word}
        </p>
      ) : (
        <p>This is a number: {word}</p>
      )}
    </div>
  );
};

export default Parameters;
