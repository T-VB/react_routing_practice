// import { useParams } from "react-route";
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Parameters from "./components/Parameters";
import "./App.css";

//put constant's here:
// const Location = (props) => {
//   const { city } = useParams();
// };

//* BrowserRouter wraps around everything in app*/

function App() {
  return (
    <BrowserRouter>
      <div>
        {/* <p>
          <Link to="/home"></Link>
          <Link to="/4"></Link>
          <Link to="/hello"></Link>
          <Link to="/hello/blue/red"></Link>
        </p> */}
        <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/:word" element={<Parameters />} />
          <Route path="/hello" element={<Parameters />} />
          <Route path="/:word/:color/:bgColor" element={<Parameters />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
